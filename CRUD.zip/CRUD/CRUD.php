<?php
//connection OF database
$db_host="localhost";
$db_user="root";
$db_pass="";
$db_name="student";
$conn=mysqli_connect($db_host,$db_user,$db_pass,$db_name);

if(mysqli_connect_errno()){
    die("Database connection failed :" .mysqli_connect_error() . "(" . mysqli_connect_errno() .")");
}
else
{
    echo "connected.<br />";
}
//INsert data Function


// $sql="INSERT INTO `class` (`ID`, `Name`, `Roll`, `Address`) VALUES (NULL, 'Mubashir', '026', 'Lahore');";

// if(mysqli_query($conn, $sql)){
//     echo " succesfully.<br />";
// }
// else{
//     echo "Unable ";
// }
//Delete data Function
/*
$sql_delete="DELETE FROM `class` WHERE id=6";

if(mysqli_query($conn, $sql_delete)){
    echo "successfully Delete.<br />";
}
else
{
    echo " unable delete data";
}*/

// Update DATABASE Function
$sql="UPDATE `class` SET `Name`='Hafiz talha',`Roll`=02,`Address`='MODEL TOWN' WHERE id=1";

if(mysqli_query($conn, $sql)){
    echo "Record update.<br />";
}
else
{
    echo "unable to update query";
}
//Read data Function

// $sql ="SELECT * FROM `class`";
// $result = mysqli_query($conn, $sql);
// $row = mysqli_fetch_assoc($result);
// if (mysqli_num_rows($result) >0){
//     while($row){
//         echo ID . $row['ID'] . Name . $row['Name'] . Roll . $row['Roll'] . Address . $row['Address'];
//     }
   
// }
// else {
//     echo "no result";
// }*/



?>